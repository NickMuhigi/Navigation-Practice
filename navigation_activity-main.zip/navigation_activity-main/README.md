# navigation_activity
This repo contains code for class activity in breakout roomfor a class that happened on 6th Feb 2025, from 13:30 - 15:00.
## Collaborators
- David Niyonshuti 
- Amandine Irakoze
- Divine Nubuhoro
- Jolly Umulisa
- Loic Cyusa
- Roxanne Niteka
## Set up and running the app
-- Make sure you have flutter and android studio install in your PC
-- Open your IDE(VScode, android Stusio, etc) and open terminal within your IDE
- Clone repository
```bash 
git clone 
```
- navigate to the repo
```bash
cd navigation_activity
```
- navigate to directory containing app
```bash
cd nav_app
```
- Run the app
```bash
flutter run
```
- Output is gone be like this one:
- 
  ![image](https://github.com/user-attachments/assets/d48bbef9-7a8e-4543-94fd-be3626aa6345)
  ![image](https://github.com/user-attachments/assets/cacddea0-e017-4304-bcff-e300d4960f50)


